import java.io.*;

public class dhtRead {
	public static void main(String[] args) {

	while(true)
	{
			try 
			{
				Runtime run = Runtime.getRuntime();
	 		  	Process proc= run.exec("sudo python dhtlib.py"); // python code ...
			  	BufferedReader stdInput = new BufferedReader(new InputStreamReader(proc.getInputStream()));
			 
	            Double humidity;
	            Double temperature;
	
			  	// read the output from the command
		    	String s = null;
		        String sOut = "";
			        
				while((s = stdInput.readLine()) != null) 
				{
					sOut=sOut+s;
			  	}
			
			    if(!(sOut.contains("ERR_RANGE")||sOut.contains("ERR_CRC")))
				{
				    humidity=Double.parseDouble(sOut);
	                System.out.println(sOut);
		        	}
			          
				// read any errors from the attempted comman
		        //Thread.sleep(1000); 
			} 
			catch (Exception e) {
				// TODO Auto-generated catch block
		  		e.printStackTrace();
			}
		}
 	}
}
