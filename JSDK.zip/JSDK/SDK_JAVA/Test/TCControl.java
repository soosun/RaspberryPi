import com.pi4j.io.gpio.GpioController;
import com.pi4j.io.gpio.GpioFactory;
import com.pi4j.io.gpio.GpioPin;
import com.pi4j.io.gpio.GpioPinDigitalInput;
import com.pi4j.io.gpio.PinPullResistance;
import com.pi4j.io.gpio.RaspiPin;

public class TCControl 
{
    public static void main(String[] args) throws InterruptedException 
	{
        // get a handle to the GPIO controller
    	final GpioController gpio = GpioFactory.getInstance();
        
        // creating the pin with parameter PinPullResistance
        // will instantly power up the pin
		final GpioPinDigitalInput pin = gpio.provisionDigitalInputPin(RaspiPin.GPIO_04,"PinTC", PinPullResistance.PULL_DOWN);

		System.out.println("TC is ready !!");
   
    	for(;;)
		{
			if(pin.isLow())
			{
				System.out.println("Not Detect !!");
			}
			else
			{
				System.out.println("Detected !!");
			}

			Thread.sleep(1000); //ms
		}	
         }
}