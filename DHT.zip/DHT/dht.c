#include <wiringPi.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#define MAXTIMINGS 85
#define DHTPIN 7
int dht11_dat[5] = {0, };

void read_dht11_dat()
{
	uint8_t laststate = HIGH;
	uint8_t counter = 0;
	uint8_t j = 0, i;
	float f;

	// DHT11은 여타 센서와 다르게 신호의 길이로 데이터를 내보냅니다.
	// 처음에 신호선으로 LOW를 18ms 동안, 그리고 20 ~ 40us동안 HIGH신호를 주면 start 신호입니다.  중간값 30us를 사용
	dht11_dat[0] = dht11_dat[1] = dht11_dat[2] = dht11_dat[3] = dht11_dat[4] = 0;
	pinMode(DHTPIN, OUTPUT);
	digitalWrite(DHTPIN, LOW);
	delay(18);

	digitalWrite(DHTPIN, HIGH);
	delayMicroseconds(40);
	pinMode(DHTPIN, INPUT);
	
	// 먼저 MAXTIMINGS만큼 for문을 반복하며 값을 읽어들입니다. 이때 MAXTIMINGS는 83의 값을 가지는데 이는 
	// 40개의 데이터 비트 * 2(LOW, HIGH가 반복되어야 데이터 1개를 읽을 수 있으므로)
	// + 3개의 처음 비트 - Response signal, pullup ready signal, 처음 start to transmit bit 해서 3개
	for(i = 0; i < MAXTIMINGS; i++) 
	{
		counter = 0;
		while(digitalRead(DHTPIN) == laststate)
		{
			counter++;
			delayMicroseconds(1);
			if(counter == 255) break;
		}

		// 이 부분에서 laststate와 반대가 되었을 경우(비트가 HIGH에서 LOW로 혹은 LOW에서 HIGH로 바뀌었을 경우를 인식합니다.
		//1us단위로 count를 증가시켜 반전되는데 시간이 얼마나 걸렸는지 짐작합니다.
		// 다만 최대 시간을 100us로 지정하여 이 시간동안 바뀌지 않을 경우, 에러로 인식하고 break와 뒤에 나오는 if문을 이용하여 에러를 검출
		laststate = digitalRead(DHTPIN);
		if(counter == 255) break; // if while breaked by timer, break for

		// 위 코드는 처음 3비트를 버린상태로, 그리고 짝수번째 비트인지를 확인합니다.
		// 홀수번째는 LOW상태의 start to transmit bit이므로 필요가 없기 때문입니다.
		// 조건이 부합할 때 i 를 8로 나눈곳에 데이터를 씁니다.
		// 앞에서 비트가 반전될 때 까지 count를 측정하였는데 이게 20이상이면 1이라고 값을 씁니다.
		// 0은 이미 초기화가 되어있으므로 무시합니다.
		// 그러면 왜 20이냐구요?
		// 데이터시트에 보면 26 ~ 28us정도를 data 0으로 지정하고 있습니다.
		// 다만 count연산과 if문연산 속도가 있기에 26정도를 바로 써주게되면 지연이 일어나서 이미 늦어버리게 됩니다.
		// 그렇기에 20이라는 값을 기준으로 비교해주는 것입니다.
		if((i >= 4) && (i % 2 == 0)) 
		{
			dht11_dat[j / 8] <<= 1 ;
			if(counter > 50) dht11_dat[j / 8] |= 1;
			j++;
		}
	}
		
	// 값이 다 쓰였으면 0, 1, 2, 3번값을 더한 값과 마지막 4번값을 비교합니다.
	// 마지막 4번째 8비트는 패리티 비트라고 부릅니다. 값이 잘 전송되었는지를 확인하기 위한 비트입니다.
	if((j >= 40) && (dht11_dat[4] == ((dht11_dat[0] + dht11_dat[1] + dht11_dat[2] + dht11_dat[3]) & 0xff))) 
	{
		f = dht11_dat[2] * 9. / 5. + 32;
	
		if (dht11_dat[0] > 0) printf("1.humidity = %d.%d %% 2.Temperature = %d.%d *C \n", dht11_dat[0], dht11_dat[1], dht11_dat[2], dht11_dat[3]);
	}
}

int main(void)
{
	if(wiringPiSetup() == -1) exit(1);
	printf("dht11 Raspberry pi\n");
	
	while(1)
	{
		read_dht11_dat();
		delay(1000);
	}
	
	return 0;
}

// gcc -o dht dht.c -lwiringPi
// sudo ./dht
